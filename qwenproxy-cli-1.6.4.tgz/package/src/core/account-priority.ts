import {
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "fs";
import { join, resolve } from "path";

interface PriorityData {
  accountOrder: string[];
  lastUpdated: number;
}

/**
 * Mock account used by test suites (TEST_MOCK_QWEN_AUTH). Must never be
 * persisted to the real priority file or it pollutes production routing.
 */
const MOCK_ACCOUNT_ID = "mock-account";

function isPersistableAccount(accountId: string): boolean {
  return accountId !== MOCK_ACCOUNT_ID;
}

import { getDataDir, getAccountPriorityPath } from "./paths.ts";

const DATA_DIR = getDataDir();
const PRIORITY_FILE = getAccountPriorityPath();

let priorityCache: PriorityData | null = null;

/** Invalidate the in-memory priority cache (test isolation). */
export function invalidatePriorityCache(): void {
  priorityCache = null;
}

function loadPriority(): PriorityData {
  if (priorityCache) return priorityCache;

  try {
    if (existsSync(PRIORITY_FILE)) {
      const data = JSON.parse(readFileSync(PRIORITY_FILE, "utf-8"));
      // Filter out any mock/test accounts that may have leaked into the file
      const accountOrder: string[] = (data.accountOrder || []).filter(
        isPersistableAccount,
      );
      priorityCache = {
        accountOrder,
        lastUpdated: data.lastUpdated || 0,
      };
      return priorityCache!;
    }
  } catch (err) {
    console.error("❌ [AccountPriority] Failed to load priority file:", (err as Error).message);
  }

  priorityCache = { accountOrder: [], lastUpdated: 0 };
  return priorityCache;
}

function savePriority(data: PriorityData): void {
  try {
    mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(PRIORITY_FILE, JSON.stringify(data, null, 2), "utf-8");
    priorityCache = data;
  } catch (err) {
    console.error("❌ [AccountPriority] Failed to save priority file:", (err as Error).message);
  }
}

/**
 * Reordena contas: conta que funcionou vai para o topo
 */
export function markAccountSuccessful(accountId: string): void {
  if (!isPersistableAccount(accountId)) return;
  const data = loadPriority();
  
  // Remove se já existe
  data.accountOrder = data.accountOrder.filter(id => id !== accountId);
  
  // Adiciona no topo
  data.accountOrder.unshift(accountId);
  data.lastUpdated = Date.now();
  
  savePriority(data);
}

/**
 * Reordena contas: conta que falhou vai para o final
 */
export function markAccountFailed(accountId: string): void {
  if (!isPersistableAccount(accountId)) return;
  const data = loadPriority();
  
  // Remove se já existe
  data.accountOrder = data.accountOrder.filter(id => id !== accountId);
  
  // Adiciona no final
  data.accountOrder.push(accountId);
  data.lastUpdated = Date.now();
  
  savePriority(data);
}

/**
 * Adiciona conta à prioridade se não existir (prioridade inicial).
 * Contas novas entram no final da lista, mantendo a ordem de configuração.
 */
export function ensureAccountInPriority(accountId: string): void {
  if (!isPersistableAccount(accountId)) return;
  const data = loadPriority();
  
  // Se já existe, não faz nada
  if (data.accountOrder.includes(accountId)) {
    return;
  }
  
  // Adiciona no final (prioridade inicial baixa)
  data.accountOrder.push(accountId);
  data.lastUpdated = Date.now();
  
  savePriority(data);
}

/**
 * Retorna contas ordenadas por prioridade (melhores primeiro)
 */
export function getAccountsByPriority<T extends { id: string }>(accounts: T[]): T[] {
  const data = loadPriority();
  
  if (data.accountOrder.length === 0) {
    return accounts;
  }
  
  // Cria mapa de prioridade (menor índice = maior prioridade)
  const priorityMap = new Map<string, number>();
  data.accountOrder.forEach((id, index) => {
    priorityMap.set(id, index);
  });
  
  // Ordena: contas na lista de prioridade vêm primeiro, depois as que não estão na lista
  return [...accounts].sort((a, b) => {
    const priorityA = priorityMap.get(a.id);
    const priorityB = priorityMap.get(b.id);
    
    // Ambos têm prioridade definida
    if (priorityA !== undefined && priorityB !== undefined) {
      return priorityA - priorityB;
    }
    
    // Apenas A tem prioridade
    if (priorityA !== undefined) {
      return -1;
    }
    
    // Apenas B tem prioridade
    if (priorityB !== undefined) {
      return 1;
    }
    
    // Nenhum tem prioridade, mantém ordem original
    return 0;
  });
}
